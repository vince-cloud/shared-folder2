import cv2
import cv2.dnn as dnn
import numpy as np

import argparse
import torch
import torch.nn.functional as F
import torch.optim as optim
from utils.DataPrePare_cls import load_data
# from resnet50 import resnet50, resnet101, resnet34
from resnet50 import resnet18
from torch.optim import lr_scheduler
import os

modelnew=dnn.readNetFromONNX('./newresnet18.onnx')
print('finish')
print(modelnew.getParam(1))

img =cv2.imread('E:/2019ZJB/ZSL2018_Zero_Shot_Learning-master/DatasetA_train_20180813/DatasetA_train_20180813/train/438d5e5781b778be91b2bc3245a85651.jpeg')
img=cv2.resize(img,(200,200))
print(img)
newimg=img[np.newaxis, :]
print(newimg)
print(newimg.shape)
newimg=np.swapaxes(newimg,1,3)
newimg=np.swapaxes(newimg,2,3)
print(newimg.shape)
print(newimg)


# print('nnimg: ',nnimg)
modelnew.setInput(newimg)
cvout=modelnew.forward()
print('cvout:', cvout[0])


#ans=modelnew.forward(newimg)

#print(ans)

#test_loader = load_data(batch_size=32,alldata=False)['test']
#for batch_idx, sample in enumerate(test_loader):
#    modelnew.setInput(sample[0].numpy())
#    cvout=modelnew.forward()
#    print(cvout)
