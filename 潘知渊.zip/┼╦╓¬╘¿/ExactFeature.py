import argparse
import torch
from utils.DataPrePare_cls import load_data
from resnet50 import resnet18,resnet50,resnet101,resnet34
import os
import scipy.io as sio
import numpy as np
from inceptionV4 import inceptionv4


os.environ["CUDA_VISIBLE_DEVICES"] = "0"


def trainFeature(model, train_loader, device):
    model.eval()
    feats = torch.empty(len(train_loader.dataset), 512)
    labels = torch.empty(len(train_loader.dataset), 1)
    with torch.no_grad():
        for batch_idx, sample in enumerate(train_loader):
            data = sample[0].to(device)
            label = torch.from_numpy(np.array(sample[1])).to(device)
            cnn_feat = model(data)[0]
            feats[batch_idx*64:(batch_idx+1)*64, :] = cnn_feat
            labels[batch_idx*64:(batch_idx+1)*64, 0] = label
        sio_content = {"features":feats.numpy(), "label":labels.numpy()}

        sio.savemat("E:/2019ZJB/program2019/data_store/feature/val_new.mat", sio_content)  #保存地址


def testFeature(model, test_loader, device):
    model.eval()
    feats = torch.empty(len(test_loader.dataset), 512)

    with torch.no_grad():
        for batch_idx, sample in enumerate(test_loader):
            print(sample[0])
            data = sample[0].to(device)
            cnn_feat = model(data)[0]
            print(cnn_feat)
            print(cnn_feat.shape)
            feats[batch_idx, :] = cnn_feat
            print("the batchidx is %d" % batch_idx)
        sio_content = {"features":feats.numpy()}

        sio.savemat("E:/2019ZJB/program2019/data_store/feature/test_new.mat", sio_content) #保存地址




if __name__=='__main__':
    parser = argparse.ArgumentParser(description='Pytorch baseline')
    parser.add_argument('--batch_size', type=int, default=16)
    parser.add_argument('--test', type=bool, default=True, help='only test?')
    parser.add_argument('--weights', type=str, default='E:/2019ZJB/program2019/resnet18datastore/new_model_save/cls149.t7', help='pretrained model path')

    args = parser.parse_args()
    device = torch.device('cpu')

    train_loader = load_data(batch_size=args.batch_size, alldata=True)['train']
    val_loader = load_data(batch_size=args.batch_size, alldata=True)['val']
    test_loader = load_data(batch_size=args.batch_size, alldata=True)['test']

    #model = resnet18(pretrained=False)
    #model.avgpool = torch.nn.AdaptiveAvgPool2d(output_size=1)
    #model.fc = torch.nn.Linear(model.fc.in_features, 7)
    #model.to(device)
    #model.load_state_dict(torch.load(args.weights))
    model=torch.load(args.weights)
    device = torch.device('cpu')
    model.to(device)
    
    if args.test:   #是否是训练集或者验证集的特征
        testFeature(model, test_loader, device)
    else:
        trainFeature(model, val_loader, device)


