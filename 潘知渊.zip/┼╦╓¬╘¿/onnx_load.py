import cv2.dnn as dnn

model_RN=dnn.readNetFromONNX('./RN1_new_model_RN.onnx')
