import argparse
import torch
import torch.nn.functional as F
import torch.optim as optim
from utils.DataPrePare_cls import load_data
from resnet50 import resnet18
from torch.optim import lr_scheduler
import numpy as np
import os
import cv2
import torch.nn as nn
from RN import RelationNetwork, AttributeNetwork

model=RelationNetwork(1024, 256)
#model = AttributeNetwork(300, 1200, 512)
model.load_state_dict(torch.load('./resnet18datastore/feature_embedding/RN1.pt'))
#model.load_state_dict(torch.load('./resnet18datastore/Attr50.pt'))
device = torch.device('cpu')
model.to(device)

dum_input=torch.randn(2,7,512)
dum_output=model(dum_input)
print(dum_output)
print(dum_output.shape)
torch.onnx.export(model, dum_input, 'RN1_new_model_RN.onnx')
