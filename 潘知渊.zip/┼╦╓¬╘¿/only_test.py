import argparse
import torch
from utils.DataPrePare_cls_test_secondtry import load_data
from resnet50 import resnet50,resnet101,resnet34
import os
import scipy.io as sio
import numpy as np
from inceptionV4 import inceptionv4

from ExactFeature_test_secondtry import Feature_Exact, test


picture_path = 'E:/2019ZJB/ZSL2018_Zero_Shot_Learning-master/DatasetA_train_20180813/DatasetA_train_20180813/train/e266ba07d18a06ae8ebf8c43df043f2e.jpeg'

test()

Feature_Exact(picture_path)

